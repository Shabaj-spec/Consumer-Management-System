
<nav id="navbar" class="navbar">
        <ul>
          <li><a href="index.php">Home</a></li>

          <li class="dropdown" ><a href="events.php">Events <i class="bi bi-chevron-down dropdown-indicator"></i></a>
        <ul> 
          <li><a href="events.php?type=all">All Events</a></li>
          <li><a href="events.php?type=ArtCulture">Music</a></li>
          <li><a href="events.php?type=ArtCulture">Arts+culture</a></li>
          <li><a href="events.php?type=Sports">Sport</a></li>
          <li><a href="events.php?type=Food">Food</a></li>
          <li><a href="events.php?type=Fund Raiser">Fund Raiser</a></li>
          </ul>
        </li>
             

          <li ><a href="groups.php"><span>Community Groups</span> </i></a>
            
          </li>
          <li><a href="post.php">Post Events</a></li>
          <li><a href="about.php">About</a></li>
          <li><a href="login.php">Login</a></li>
        </ul>
      </nav><!-- .navbar -->