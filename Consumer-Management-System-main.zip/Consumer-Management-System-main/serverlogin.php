 <?php
  	$db_hostname = 'localhost';  
 	$db_username = 'root';  // username
  	$db_password = 'root'; // password
    $db_database = 'whats_happening'; 
?>
